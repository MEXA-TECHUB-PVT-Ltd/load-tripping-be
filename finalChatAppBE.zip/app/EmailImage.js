const imageURL = 'https://res.cloudinary.com/dxfdrtxi3/image/upload/v1696248204/o8linpmhgjcsyt5lmwvf.jpg';

module.exports =  imageURL;
