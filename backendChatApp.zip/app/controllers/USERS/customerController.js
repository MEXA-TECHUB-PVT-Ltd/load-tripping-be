const { pool } = require("../../config/db.config");
const { v4: uuidv4 } = require('uuid');

exports.registerCustomer = async (req, res, next) => {

    const client = await pool.connect();
    try {
        const {
          
            image,
            user_name,
            email,
            password

        } = req.body;
        // const company_user = false;
        if (email === null || email === "" || email === undefined) {
            res.json({ error: true, message: "Please Provide User Email" });

        } else {
            const userDataCheck = await pool.query("SELECT * FROM users WHERE email=$1",
                [email]);

            if (userDataCheck.rows.length === 0) {
                console.log(uuidv4())
                const userData = await pool.query("INSERT INTO users(uniq_id,image,user_name,email,password) VALUES($1,$2,$3,$4,$5) returning *",
                    [
                        uuidv4(),
                        image || null,
                        user_name,
                        email,
                        password
                    ])
                const data = userData.rows[0]
                console.log(data)
                if (userData.rows.length === 0) {
                    res.json({ error: true, data, message: "Can't Create User" });


                } else {
                    res.json({ error: false, data, message: "User Created Successfully" });

                }



            } else {
                const data = userDataCheck.rows[0]
                res.json({ error: true, data, message: "Email Already Exist" });

            }
        }




    }
    catch (err) {
        res.json({ error: true, data: [], message: "Catch eror" });

    } finally {
        client.release();
    }

}

exports.login = async (req, res) => {
    const client = await pool.connect();
    try {
        const {
            email,
            password

        } = req.body;
        // const company_user = false;
        if (email === null || email === "" || email === undefined) {
            res.json({ error: true, message: "Please Provide Email" });

        } else {
            const userDataCheck = await pool.query("SELECT * FROM users WHERE email=$1",
                [email]);

            if (userDataCheck.rows.length === 0) {

                res.json({ error: true, data:[], message: "No User Exist for this Email" });



            } else {
                const data = userDataCheck.rows[0]
                const passwordUser=userDataCheck.rows[0].password
                console.log(password)
                console.log(passwordUser)
                if(password===passwordUser){
                    res.json({ error: false, data, message: "Login Successfully" });

                }else{
                    res.json({ error: true, data:[], message: "Invalid Credentials" });

                }
            }
        }

    }
    catch (err) {
        res.json({ error: true, data: [], message: "Catch eror" });

    } finally {
        client.release();
    }
}

exports.admingetAllCustomers = async (req, res) => {
    const client = await pool.connect();
    try {
        const {
            user_id,
            type
        } = req.body;
        if(type===null||type===undefined||type===""){
            // when type null show only admin 
            const query = 'SELECT * FROM users WHERE type =$1'
            const result = await pool.query(query, ["admin"]);
            // get messages 
            const Data= result.rows
            let Array=[];
            for(let i=0;i<Data.length;i++){
                const customerId=Data[i].user_id
                const queryText = `
                SELECT sender = $1 AS from_self, message AS message,type AS type,
                readStatus AS readStatus,
                created_at AS created_at
                FROM messages
                WHERE (sender = $1 AND to_user = $2) OR (sender = $2 AND to_user = $1)
                ORDER BY created_at ASC 
              `;
            
              let resultMessages = await client.query(queryText, [user_id, customerId]);
              // Filter the array to get objects with readstatus false and from_self false
    // console.log(resultMessages.rows)
              const filteredResults = resultMessages.rows.filter((row) => {
        return row.readstatus === "false" && row.from_self === false;
      });
    //   console.log("filteredResults")
    
    //   console.log(filteredResults)
              Array.push({
                user_id:Data[i].user_id,
                email:Data[i].email,
                password:Data[i].password,
                image:Data[i].image,
                user_name:Data[i].user_name,
                uniq_id:Data[i].uniq_id,
                unreadMessages:filteredResults.length
              })
            }
    
    
            if (result.rows) {
                res.json({
                    message: "All Users Fetched",
                    status: true,
                    result: Array
                })
            }
            else {
                res.json({
                    message: "could not fetch",
                    status: false,
                })
            }
        }else{
            // type admin (show all users )
            const query = 'SELECT * FROM users WHERE user_id <> $1'
            const result = await pool.query(query, [user_id]);
            // get messages 
            const Data= result.rows
            let Array=[];
            for(let i=0;i<Data.length;i++){
                const customerId=Data[i].user_id
                const queryText = `
                SELECT sender = $1 AS from_self, message AS message,type AS type,
                readStatus AS readStatus,
                created_at AS created_at
                FROM messages
                WHERE (sender = $1 AND to_user = $2) OR (sender = $2 AND to_user = $1)
                ORDER BY created_at ASC 
              `;
            
              let resultMessages = await client.query(queryText, [user_id, customerId]);
              // Filter the array to get objects with readstatus false and from_self false
    // console.log(resultMessages.rows)
              const filteredResults = resultMessages.rows.filter((row) => {
        return row.readstatus === "false" && row.from_self === false;
      });
    //   console.log("filteredResults")
    
    //   console.log(filteredResults)
              Array.push({
                user_id:Data[i].user_id,
                email:Data[i].email,
                password:Data[i].password,
                image:Data[i].image,
                user_name:Data[i].user_name,
                uniq_id:Data[i].uniq_id,
                unreadMessages:filteredResults.length
              })
            }
    
    
            if (result.rows) {
                res.json({
                    message: "All Users Fetched",
                    status: true,
                    result: Array
                })
            }
            else {
                res.json({
                    message: "could not fetch",
                    status: false,
                })
            }
        }
       
    }
    catch (err) {
        console.log(err)
        res.json({
            message: "Error Occurred",
            status: false,
            error: err.message
        })
    }
    finally {
        client.release();
    }
}
exports.getAllCustomers = async (req, res) => {
    const client = await pool.connect();
    try {
        const {
            user_id,
        } = req.body;
    //    const type="admin"
        const query = 'SELECT * FROM users WHERE user_id <> $1 '
        const result = await pool.query(query, [user_id]);
        // get messages 
        // const Data= result.rows
        const Data = result.rows.filter(user => user.type !== 'admin');
        // console.log(Data)
        let Array=[];
        for(let i=0;i<Data.length;i++){
            const customerId=Data[i].user_id
            const queryText = `
            SELECT sender = $1 AS from_self, message AS message,type AS type,
            readStatus AS readStatus,
            created_at AS created_at
            FROM messages
            WHERE (sender = $1 AND to_user = $2) OR (sender = $2 AND to_user = $1)
            ORDER BY created_at ASC 
          `;
        
          let resultMessages = await client.query(queryText, [user_id, customerId]);
          // Filter the array to get objects with readstatus false and from_self false
// console.log(resultMessages.rows)
          const filteredResults = resultMessages.rows.filter((row) => {
    return row.readstatus === "false" && row.from_self === false;
  });
//   console.log("filteredResults")

//   console.log(filteredResults)
          Array.push({
            user_id:Data[i].user_id,
            email:Data[i].email,
            password:Data[i].password,
            image:Data[i].image,
            user_name:Data[i].user_name,
            uniq_id:Data[i].uniq_id,
            unreadMessages:filteredResults.length
          })
        }


        if (result.rows) {
            res.json({
                message: "All Users Fetched",
                status: true,
                result: Array
            })
        }
        else {
            res.json({
                message: "could not fetch",
                status: false,
            })
        }
    }
    catch (err) {
        console.log(err)
        res.json({
            message: "Error Occurred",
            status: false,
            error: err.message
        })
    }
    finally {
        client.release();
    }
}

exports.logout = async (req, res) => {
    const client = await pool.connect();
    try {
        const {
            user_id,

        } = req.body;
        // const company_user = false;
        if (!user_id) return res.json({ msg: "User id is required " });
        onlineUsers.delete(req.user_id);
        res.json({ error: false,  message: "Logout Successfully" });

    }
    catch (err) {
        res.json({ error: true, data: [], message: "Catch eror" });

    } finally {
        client.release();
    }
}

